// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Optional: Alert on volunteer form submission (HTML only)
const volunteerForm = document.querySelector('form');
if (volunteerForm) {
    volunteerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for registering as a volunteer! We will contact you soon.');
        volunteerForm.reset();
    });
}
