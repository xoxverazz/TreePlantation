<?php
include "../backend/config.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $db->query("DELETE FROM events WHERE id = $id");

    // Redirect back to manage events
    header("Location: admin.php");
    exit();
}
?>
