<?php
include "../backend/config.php";

$id = $_GET['id'];

// Fetch existing event data
$result = $db->query("SELECT * FROM events WHERE id = $id");
$event = $result->fetch_assoc();

// Update event
if (isset($_POST['update'])) {
    $title = $_POST['title'];
    $desc  = $_POST['description'];
    $date  = $_POST['event_date'];

    $db->query("UPDATE events 
                SET title='$title', description='$desc', event_date='$date'
                WHERE id=$id");

    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Event</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container my-5">
<h2 class="text-success fw-bold">Edit Event</h2>

<form method="POST" class="card p-4">
<input type="text" name="title" class="form-control mb-2"
       value="<?= $event['title']; ?>" required>

<textarea name="description" class="form-control mb-2" required><?= $event['description']; ?></textarea>

<input type="date" name="event_date" class="form-control mb-2"
       value="<?= $event['event_date']; ?>" required>

<button name="update" class="btn btn-success">Update Event</button>
<a href="manage_events.php" class="btn btn-secondary">Cancel</a>
</form>

</div>
</body>
</html>
