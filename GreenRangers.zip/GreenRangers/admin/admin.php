<?php include ".././backend/config.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>Admin | Manage Events</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
/* 🌈 Animated Gradient Background */
body {
    min-height: 100vh;
    background: linear-gradient(-45deg, #198754, #20c997, #0dcaf0, #6f42c1);
    background-size: 400% 400%;
    animation: gradientBG 10s ease infinite;
}

@keyframes gradientBG {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* 🔍 Search Animation */
.search-box {
    transition: all 0.4s ease;
    border: 2px solid #198754;
}
.search-box:focus {
    box-shadow: 0 0 15px rgba(25, 135, 84, 0.8);
    transform: scale(1.03);
}

/* ✨ Card Animation */
.card {
    animation: slideUp 0.7s ease;
}
@keyframes slideUp {
    from { opacity: 0; transform: translateY(40px); }
    to { opacity: 1; transform: translateY(0); }
}

/* 🔘 Back Button */
.back-btn {
    transition: transform 0.3s ease;
}
.back-btn:hover {
    transform: translateX(-5px);
}
</style>
</head>

<body>

<div class="container my-5">

<!-- 🔙 Back to Home -->
<a href="../frontend/index.php" class="btn btn-light back-btn mb-3">
⬅ Back to Home
</a>

<h2 class="text-white fw-bold mb-3">Manage Events</h2>

<!-- 🔍 Search Bar -->
<input type="text" id="searchInput" class="form-control mb-4 search-box"
       placeholder="🔍 Search events...">

<!-- ➕ Add Event Form -->
<form method="POST" class="card p-4 mb-4 shadow">
<input type="text" name="title" class="form-control mb-2" placeholder="Event Title" required>
<textarea name="description" class="form-control mb-2" placeholder="Description" required></textarea>
<input type="datetime-local" name="event_date" class="form-control mb-2" required>
<button name="add" class="btn btn-success">Add Event</button>
</form>

<?php
if (isset($_POST['add'])) {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $date = $_POST['event_date'];

    $db->query("INSERT INTO events (title, description, event_date)
                VALUES ('$title','$desc','$date')");
}
?>

<!-- 📋 Event List -->
<div class="card shadow">
<table class="table table-bordered mb-0" id="eventTable">
<tr class="table-success">
<th>Title</th>
<th>Description</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php
$result = $db->query("SELECT * FROM events ORDER BY event_date DESC");
while ($row = $result->fetch_assoc()) {
?>
<tr>
<td><?= $row['title']; ?></td>
<td><?= $row['description']; ?></td>
<td><?= $row['event_date']; ?></td>
<td>
<a href="edit_event.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
<a href="delete_event.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm">🗑 Delete</a>
</td>
</tr>
<?php } ?>
</table>
</div>

</div>

<!-- 🔍 Live Search Script -->
<script>
document.getElementById("searchInput").addEventListener("keyup", function () {
    let value = this.value.toLowerCase();
    let rows = document.querySelectorAll("#eventTable tr");

    rows.forEach((row, index) => {
        if (index === 0) return;
        row.style.display = row.innerText.toLowerCase().includes(value) ? "" : "none";
    });
});
</script>

</body>
</html>
