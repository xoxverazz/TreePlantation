<?php
session_start();

// If user not logged in → redirect to login page
if (!isset($_SESSION['user_email'])) {
    header('location: login.html');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard | Green Rangers</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">
<div class="container">
<img src="../tree .png" width="30px" height="30px" alt="" srcset="">
<a class="navbar-brand fw-bold" href="#">Green Rangers Dashboard</a>

<div class="ms-auto">
<a href="../frontend/logout.php" class="btn btn-light">Logout</a>
</div>
</div>
</nav>

<section class="container my-5">
<h2 class="text-success fw-bold">Welcome, <?php echo $_SESSION['user_name']; ?> 👋</h2>

<div class="card mt-4 shadow-sm">
<div class="card-body">

<h5 class="mb-3">Your Details</h5>

<p><strong>Name:</strong> <?php echo $_SESSION['user_name']; ?></p>
<p><strong>Email:</strong> <?php echo $_SESSION['user_email']; ?></p>
<!-- <p><strong>Mobile Number:</strong> <?php echo $_SESSION['user_phone'] ?></p> -->
<p><strong>Selected Event:</strong> <?php echo $_SESSION['event']; ?></p>

</div>
</div>

</section>

<footer class="bg-success text-white text-center p-3 mt-5">
<p class="mb-0">© 2025 Green Rangers</p>
</footer>

</body>
</html>
