<?php
include "../backend/config.php";   // adjust path if needed
?>

!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Volunteer | Green Rangers</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
/* Full page gradient background */
body {
    background: linear-gradient(135deg, #a8edea, #fed6e3, #fddb92);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Navbar customization */
.navbar {
    background: #2e7d32 !important;
}

/* Center the form */
section.container {
    max-width: 600px;
    margin-top: 60px;
    background: rgba(255, 255, 255, 0.95);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
    animation: fadeInUp 1s ease forwards;
}

/* Fade in animation */
@keyframes fadeInUp {
    0% {opacity: 0; transform: translateY(40px);}
    100% {opacity: 1; transform: translateY(0);}
}

/* Input and select effects */
input, select {
    transition: all 0.3s ease;
}
input:focus, select:focus {
    border-color: #2e7d32;
    box-shadow: 0 0 10px rgba(46,125,50,0.5);
    outline: none;
}

/* Submit button */
button.btn-success {
    background: linear-gradient(45deg, #2e7d32, #81c784);
    border: none;
    font-weight: bold;
    transition: all 0.3s ease;
}
button.btn-success:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(46,125,50,0.4);
}

/* Footer */
footer {
    margin-top: 50px;
    background: #2e7d32 !important;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
}

/* Animated heading */
h2.text-success {
    background: linear-gradient(90deg, #56ab2f, #a8e063);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: textGlow 2s infinite alternate;
}

@keyframes textGlow {
    0% {text-shadow: 0 0 5px #a8e063;}
    100% {text-shadow: 0 0 20px #56ab2f;}
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
<div class="container">
<img src="../tree .png" width="30px" height="30px" alt="" srcset="">
<a class="navbar-brand fw-bold" href="index.html">Green Rangers</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>
 <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php">Past Events</a></li>
                <li class="nav-item"><a class="nav-link" href="event.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="volunteer.php">Volunteer</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>
        </div>
</div>
</nav>

<section class="container my-5 position-relative">
  <!-- Back to Home Button -->
  <a href="index.php" class="btn btn-success mb-4" style="background: linear-gradient(45deg, #56ab2f, #a8e063); font-weight:bold; transition: transform 0.3s;">
    ← Back to Home
  </a>

  <h2 class="text-success fw-bold text-center mb-3">Volunteer Registration</h2>
  <p class="text-center">Fill in the form below to join our environmental initiatives.</p>

  <form method="post" action="../backend/registration.php">
    <div class="mb-3">
      <label class="form-label">Full Name</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Confirm Password</label>
      <input type="password" name="cpassword" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Phone</label>
      <input type="text" name="phone" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Event</label>
     <select name="event" class="form-select" required>
  <option value="">Select Event</option>

  <?php
  $query = "SELECT title FROM events ORDER BY event_date ASC";
  $result = $db->query($query);

  if ($result && $result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
          echo "<option value='{$row['title']}'>{$row['title']}</option>";
      }
  } else {
      echo "<option value=''>No events available</option>";
  }
  ?>
</select>

    </div>
    <button type="submit" name="submit" class="btn btn-success w-100">Register</button>
    <p class="mt-3 text-center">Already registered?  
      <a href="login.php" class="text-success fw-bold">Login</a>
    </p>
  </form>
</section>


<footer class="bg-success text-white text-center p-3 mt-5">
<p class="mb-0">© 2025 Green Rangers | Pune, India</p>
<p class="mb-0">Contact: greenrangers@gmail.com</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
