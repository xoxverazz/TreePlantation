<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About | Green Rangers</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #d4fc79, #96e6a1); /* Gradient background */
    min-height: 100vh;
  }

  section.container {
    background: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    margin-top: 30px;
    animation: fadeInUp 1s ease forwards;
    opacity: 0;
  }

  h2, h4 {
    animation: fadeInDown 1s ease forwards;
    opacity: 0;
  }

  ul li {
    margin-bottom: 10px;
    font-weight: 500;
    animation: fadeIn 1.2s ease forwards;
    opacity: 0;
  }

  /* Animations */
  @keyframes fadeInUp {
    0% { transform: translateY(40px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }

  @keyframes fadeInDown {
    0% { transform: translateY(-20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }

  @keyframes fadeIn {
    0% { opacity: 0; }
    100% { opacity: 1; }
  }

  /* Back to Home Button */
  .back-home {
    display: inline-block;
    margin-bottom: 20px;
    background: linear-gradient(45deg, #56ab2f, #a8e063);
    color: #fff;
    font-weight: bold;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    transition: transform 0.3s, background 0.3s;
  }

  .back-home:hover {
    transform: scale(1.05);
    background: linear-gradient(45deg, #a8e063, #56ab2f);
  }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">
<div class="container">
<img src="../tree .png" width="30px" height="30px" alt="" srcset="">
<a class="navbar-brand fw-bold" href="index.php">Green Rangers</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link active" href="about.php">About</a></li>
<li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
<li class="nav-item"><a class="nav-link" href="volunteer.php">Volunteer</a></li>
<li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
</ul>
</div>
</div>
</nav>

<section class="container my-5">
  <a href="index.php" class="back-home">← Back to Home</a>
  
  <h2 class="text-success fw-bold mb-3">About Green Rangers</h2>
  <p>
    Green Rangers is a passionate, youth-driven non-profit environmental organization based in Pune, committed to protecting 
    and restoring the planet’s green cover. 🌱 We aim to combat deforestation, promote tree plantation, and create 
    environmental awareness in the community. 🌿
  </p>

  <h4 class="mt-4">Objectives</h4>
  <ul>
    <li>Expand reach and scope of activities in local and global communities.</li>
    <li>Manage and track plantation drives efficiently with volunteers.</li>
    <li>Maintain accurate records of environmental efforts and volunteer contributions.</li>
    <li>Educate people on tree plantation, deforestation, and sustainability.</li>
    <li>Gather feedback for improvement and implement innovative solutions.</li>
  </ul>
</section>

<footer class="bg-success text-white text-center p-3 mt-5">
<p class="mb-0">© 2025 Green Rangers | Pune, India</p>
<p class="mb-0">Contact: greenrangers@gmail.com</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Trigger animations on load
  window.addEventListener('load', () => {
    document.querySelectorAll('section.container, h2, h4, ul li').forEach(el => {
      el.style.opacity = 1;
    });
  });
</script>

</body>
</html>
