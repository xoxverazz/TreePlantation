<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | Green Rangers</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
/* ===== Animated Gradient Background for the Login Section ===== */
.login-section {
    background: linear-gradient(135deg, #a8e063, #56ab2f, #f0e130, #ff7e5f);
    background-size: 400% 400%;
    animation: gradientBG 15s ease infinite;
    padding: 50px 20px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.2);
}

/* Gradient animation */
@keyframes gradientBG {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

/* Form inside the login section */
.login-form {
    background: rgba(255,255,255,0.85);
    padding: 30px;
    border-radius: 15px;
    max-width: 450px;
    margin: auto;
    box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}

/* Buttons */
.btn-success {
    background: linear-gradient(45deg, #00ff99, #00ccff);
    border: none;
    transition: 0.3s;
    font-weight: bold;
}

.btn-success:hover {
    background: linear-gradient(45deg, #ff4081, #ffcc00);
    transform: scale(1.05);
}

/* Back to Home button */
.back-home {
    text-align: center;
    margin-bottom: 20px;
}

/* Headings */
h2 {
    text-align: center;
    margin-bottom: 20px;
    text-shadow: 1px 1px 3px #333;
}
.navbar>.mycontainer, .navbar>.mycontainer-fluid, .navbar>.container-lg, .navbar>.container-md, .navbar>.container-sm, .navbar>.container-xl, .navbar>.container-xxl {
    display: flex;
    flex-wrap: inherit;
    align-items: center;
    justify-content:flex-start;
    margin-left: 30px;
}
</style>
</head>
<body>

<!-- Original Header (unchanged) -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
<div class="mycontainer">
<img src="../tree .png" width="30px" height="30px" alt="" srcset="">
<a class="navbar-brand fw-bold" href="index.php">Green Rangers</a>
</div>
</nav>

<!-- Login Section -->
<section class="container my-5 login-section">
    <div class="login-form">
        <!-- Back to Home Button -->
        <div class="back-home">
            <a href="index.php" class="btn btn-success btn-lg">🏠 Back to Home</a>
        </div>

        <h2 class="text-success fw-bold">Login</h2>
        <p class="text-center">Enter your email & password to continue.</p>

        <form method="post" action="../backend/login.php">
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button type="submit" name="submit" class="btn btn-success w-100">Login</button>

            <p class="mt-3 text-center">Don't have an account?  
            <a href="volunteer.php" class="text-success fw-bold">Register</a></p>
        </form>
    </div>
</section>

<!-- Original Footer (unchanged) -->
<footer class="bg-success text-white text-center p-3 mt-5">
<p class="mb-0">© 2025 Green Rangers | Pune, India</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
