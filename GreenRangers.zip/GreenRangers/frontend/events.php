<?php
include "../backend/config.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Events | Green Rangers</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
/* 🌈 Background Image + Gradient Overlay */
body {
    background:
        linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
        url("https://images.unsplash.com/photo-1500530855697-b586d89ba3ee");
    background-size: cover;
    background-attachment: fixed;
    background-position: center;
}

/* 🔙 Back Button */
.back-btn {
    background: linear-gradient(45deg, #20c997, #198754);
    color: white;
    border-radius: 30px;
    padding: 8px 18px;
    transition: all 0.3s ease;
    animation: slideIn 1s ease;
}
.back-btn:hover {
    transform: translateX(-8px) scale(1.05);
    box-shadow: 0 10px 25px rgba(0,0,0,0.4);
    color: #fff;
}

@keyframes slideIn {
    from { opacity: 0; transform: translateX(-30px); }
    to { opacity: 1; transform: translateX(0); }
}

/* ✨ Title Animation */
h2 {
    animation: fadeDown 1s ease;
}

/* 🟢 Cards */
.card {
    background: rgba(255,255,255,0.95);
    border-radius: 15px;
    transition: all 0.4s ease;
    animation: fadeUp 0.8s ease;
}
.card:hover {
    transform: translateY(-10px) scale(1.03);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}

/* Floating Effect */
.col-md-4 {
    animation: float 4s ease-in-out infinite;
}
.col-md-4:nth-child(2) { animation-delay: 0.3s; }
.col-md-4:nth-child(3) { animation-delay: 0.6s; }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(40px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes fadeDown {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes float {
    0% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
    100% { transform: translateY(0); }
}

/* Button Hover */
.btn-success:hover {
    transform: scale(1.1);
}
</style>
</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow">
<div class="container">
<a class="navbar-brand fw-bold" href="index.php">🌱 Green Rangers</a>
<div class="collapse navbar-collapse">
<ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link active" href="events.php">Events</a></li>
<li class="nav-item"><a class="nav-link" href="volunteer.php">Volunteer</a></li>
</ul>
</div>
</div>
</nav>

<!-- 🔙 Back Button -->
<div class="container mt-4">
<a href="index.php" class="btn back-btn">
⬅ Back to Home
</a>
</div>

<!-- Events Section -->
<section class="container my-4">
<h2 class="text-white fw-bold mb-4 text-center">
🌿 Upcoming & Past Events
</h2>

<div class="row">

<?php
$result = $db->query("SELECT * FROM events ORDER BY event_date DESC");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title text-success fw-bold">
                    <?= htmlspecialchars($row['title']); ?>
                </h5>

                <p class="card-text">
                    <?= htmlspecialchars($row['description']); ?>
                </p>

                <p class="text-muted">
                    📅 <?= date("d M Y", strtotime($row['event_date'])); ?>
                </p>

                <a href="volunteer.php" class="btn btn-success btn-sm">
                    Register
                </a>
            </div>
        </div>
    </div>
<?php
    }
} else {
    echo "<p class='text-center text-white'>No events available.</p>";
}
?>

</div>
</section>

<!-- Footer -->
<footer class="text-white text-center p-3 mt-5"
        style="background: linear-gradient(45deg, #198754, #20c997);">
<p class="mb-0">© 2025 Green Rangers | Pune, India</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
