<?php
 include '../backend/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Registration | Green Rangers</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #96fbc4, #f9f586, #ff9a9e);
    min-height: 100vh;
    padding-top: 50px;
    padding-bottom: 50px;
  }

  section.container {
    background: rgba(255, 255, 255, 0.95);
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    max-width: 500px;
    width: 100%;
    margin: 50px auto;
    animation: fadeInUp 1s ease forwards;
    opacity: 0;
    transition: transform 0.3s, background 0.3s;
  }

  section.container:hover {
    background: rgba(255, 255, 255, 1);
    transform: scale(1.02);
  }

  h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #2c6e49;
    animation: fadeInDown 1s ease forwards;
    opacity: 0;
  }

  button.btn-success {
    width: 100%;
    background: linear-gradient(45deg, #56ab2f, #a8e063);
    border: none;
    transition: transform 0.3s, background 0.3s;
  }

  button.btn-success:hover {
    transform: scale(1.05);
    background: linear-gradient(45deg, #a8e063, #56ab2f);
  }

  a.text-success {
    transition: color 0.3s;
  }

  a.text-success:hover {
    color: #2c6e49;
  }

  @keyframes fadeInUp {
    0% { transform: translateY(40px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }

  @keyframes fadeInDown {
    0% { transform: translateY(-20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }
</style>
</head>
<body>

<!-- KEEP YOUR ORIGINAL NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
<div class="container">
<img src="../tree .png" width="30px" height="30px" alt="" srcset="">
<a class="navbar-brand fw-bold" href="index.php">Green Rangers</a>
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
<li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
<li class="nav-item"><a class="nav-link" href="volunteer.php">Volunteer</a></li>
<li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
</ul>
</div>
</div>
</nav>

<section class="container">
<h2 class="fw-bold">Admin Registration</h2>
<p>Fill in the form below to join our environmental initiatives.</p>

<form method="post" action="../backend/registrationadmin.php">

<!-- hidden user type -->
<input type="hidden" name="type" value="admin">

<div class="mb-3">
<label class="form-label">Full Name</label>
<input type="text" name="name" class="form-control" required>
</div>

<div class="mb-3">
<label class="form-label">Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label class="form-label">Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="mb-3">
<label class="form-label">Confirm Password</label>
<input type="password" name="cpassword" class="form-control" required>
</div>

<div class="mb-3">
<label class="form-label">Phone</label>
<input type="text" name="phone" class="form-control" required>
</div>

<button type="submit" name="submit" class="btn btn-success">Register</button>

<p class="mt-3">Already registered?
<a href="login.php" class="text-success fw-bold">Login</a></p>

<a href="index.php" class="btn btn-light mt-2 w-100">← Back to Home</a>

</form>
</section>

<!-- KEEP YOUR ORIGINAL FOOTER -->
<footer class="bg-success text-white text-center p-3 mt-5">
<p class="mb-0">© 2025 Green Rangers | Pune, India</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  window.addEventListener('load', () => {
    document.querySelector('section.container').style.opacity = 1;
  });
</script>

</body>
</html>
