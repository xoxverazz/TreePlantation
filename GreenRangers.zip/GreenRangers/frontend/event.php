<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Events | Green Rangers</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
/* ===== Background ===== */
body {
    background: linear-gradient(135deg, #a8e063, #56ab2f, #f0e130, #ff7e5f);
    background-size: 400% 400%;
    animation: gradientBG 15s ease infinite;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

@keyframes gradientBG {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

/* ===== Buttons ===== */
.btn-success {
    background: linear-gradient(45deg, #00ff99, #00ccff);
    border: none;
    transition: 0.3s;
    color: #fff;
    font-weight: bold;
}

.btn-success:hover {
    background: linear-gradient(45deg, #ff4081, #ffcc00);
    transform: scale(1.05);
    color: #fff;
}

/* ===== Cards ===== */
.card {
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
}

/* ===== Card Images ===== */
.card-img-top {
    height: 200px;
    object-fit: cover;
}

/* ===== Headings ===== */
h2 {
    text-shadow: 1px 1px 3px #333;
}

/* ===== Back to Home Button ===== */
.back-home {
    display: inline-block;
    margin-bottom: 20px;
}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
<div class="container">
<img src="../tree .png" width="30px" height="30px" alt="" srcset="">
<a class="navbar-brand fw-bold" href="index.php">Green Rangers</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
<li class="nav-item"><a class="nav-link active" href="event.php">Events</a></li>
<li class="nav-item"><a class="nav-link" href="volunteer.php">Volunteer</a></li>
<li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
</ul>
</div>
</div>
</nav>

<!-- Page Content -->
<section class="container my-5">
<h2 class="text-center text-white fw-bold mb-4">Upcoming and Past Events</h2>

<!-- Back to Home Button -->
<div class="text-center back-home">
  <a href="index.php" class="btn btn-success btn-lg">🏠 Back to Home</a>
</div>

<div class="row my-4 g-4">
  <!-- Event 1 -->
  <div class="col-md-4">
    <div class="card shadow">
      <img src="https://media.assettype.com/sentinelassam-english%2F2025-06-06%2Fm7b9nh57%2FWorld-Environment-Day.webp?w=480&dpr=2&auto=format%2Ccompress&fit=max&q=85" class="card-img-top" alt="Plantation Drive Pune">
      <div class="card-body">
        <h5 class="card-title">Plantation Drive - Pune</h5>
        <p class="card-text">Join us to plant 500 trees at local parks. Date: 20th Nov 2025</p>
        <a href="volunteer.php" class="btn btn-success btn-sm">Register</a>
      </div>
    </div>
  </div>

  <!-- Event 2 -->
  <div class="col-md-4">
    <div class="card shadow">
      <img src="https://trilliontrees.org/wp-content/uploads/2022/07/money-2724241_1920_Pixabay_Nattanan-Kanchanaprat.jpg" class="card-img-top" alt="Forest Restoration Drive">
      <div class="card-body">
        <h5 class="card-title">Forest Restoration - Lonavala</h5>
        <p class="card-text">Help restore degraded forest areas. Date: 5th Dec 2025</p>
        <a href="volunteer.php" class="btn btn-success btn-sm">Register</a>
      </div>
    </div>
  </div>

  <!-- Event 3 -->
  <div class="col-md-4">
    <div class="card shadow">
      <img src="https://www.dsndp.com/images/activities/plantation/treeConservation/Vasai_Virar/tree_plantation_vasai_virar_1.jpg" class="card-img-top" alt="Awareness Campaign Pune">
      <div class="card-body">
        <h5 class="card-title">Awareness Campaign - Pune</h5>
        <p class="card-text">Spread awareness about deforestation. Date: 15th Dec 2025</p>
        <a href="volunteer.php" class="btn btn-success btn-sm">Join Us</a>
      </div>
    </div>
  </div>
</div>
</section>

<!-- Footer -->
<footer class="bg-success text-white text-center p-3 mt-5">
<p class="mb-0">© 2025 Green Rangers | Pune, India</p>
<p class="mb-0">Contact: greenrangers@example.com</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
