<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Login | Green Rangers</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #96fbc4, #f9f586, #ff9a9e);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-top: 50px;
    padding-bottom: 50px;
  }

  section.container {
    background: rgba(255, 255, 255, 0.95);
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    max-width: 450px;
    width: 100%;
    animation: fadeInUp 1s ease forwards;
    opacity: 0;
  }

  h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #2c6e49;
    animation: fadeInDown 1s ease forwards;
    opacity: 0;
  }

  .back-home {
    display: inline-block;
    margin-bottom: 20px;
    background: linear-gradient(45deg, #56ab2f, #a8e063);
    color: #fff;
    font-weight: bold;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    transition: transform 0.3s, background 0.3s;
  }

  .back-home:hover {
    transform: scale(1.05);
    background: linear-gradient(45deg, #a8e063, #56ab2f);
  }

  button.btn-success {
    width: 100%;
    background: linear-gradient(45deg, #56ab2f, #a8e063);
    border: none;
    transition: transform 0.3s, background 0.3s;
  }

  button.btn-success:hover {
    transform: scale(1.05);
    background: linear-gradient(45deg, #a8e063, #56ab2f);
  }

  /* Animations */
  @keyframes fadeInUp {
    0% { transform: translateY(40px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }

  @keyframes fadeInDown {
    0% { transform: translateY(-20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }

</style>
</head>
<body>

<section class="container">
  <a href="index.php" class="back-home">← Back to Home</a>
  <h2 class="fw-bold">Login</h2>

  <form method="post" action="../backend/adminlogin.php">
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required>
    </div>

    <button type="submit" name="login" class="btn btn-success">Login</button>
  </form>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  window.addEventListener('load', () => {
    document.querySelector('section.container').style.opacity = 1;
  });
</script>

</body>
</html>
