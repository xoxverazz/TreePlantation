<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Green Rangers | Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">

</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
        <img src="../tree .png" width="30px" height="30px" alt="" srcset="">
        <a class="navbar-brand fw-bold" href="#home">Green Rangers</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="#home">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                <li class="nav-item"><a class="nav-link" href="#events">Past Events</a></li>
                <li class="nav-item"><a class="nav-link" href="#event">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                <li class="nav-item"></li><a href="adminlogin.php" class="btn btn-light  btn-xl">Admin Login</a></li>
            </ul>
        </div>
    </div>
</nav>


<!-- Hero Section -->
<header class="text-white text-center p-5">
    <h1 class="fw-bold">Tree Plantation & Deforestation Control</h1>
    <p class="lead">Protecting the planet one tree at a time.</p>
    <a href="volunteer.php" class="btn btn-volunteer btn-lg mt-3">Join as Volunteer</a>

</header>

<!-- About Preview -->
<section class="container my-5" id="about">
    <h2 class="text-success fw-bold mb-3">About Green Rangers</h2>
    <p class="about-text">
        Green Rangers is a passionate, youth-driven non-profit organization committed to protecting and restoring the planet’s green cover. 
        🌱 We organize large-scale tree plantation drives, work tirelessly to combat deforestation, and inspire young people everywhere 
        to take meaningful action for a greener, cleaner future. 🌿 Join us to make a real impact on our environment and community!
    </p>
    <a href="about.php" class="btn btn-success">Read More</a>
<br>
    <h2 class="text-success fw-bold text-center mb-4">
         Our Tree Plantation Activities 🌱
    </h2>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow-lg">
                <img src="https://res.cloudinary.com/dxb5duy6k/images/c_scale,w_848,h_476,dpr_1.25/f_webp,q_auto/v1759924167/Mega-Tree-Sapling-scaled/Mega-Tree-Sapling-scaled.jpg?_i=AA" class="card-img-top" alt="Tree Plantation">
                <div class="card-body text-center">
                    <p class="card-text">Community Tree Plantation Drive</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-lg">
                <img src="https://www.toronto.ca/wp-content/uploads/2023/01/96a1-tree-planting-stewardship-events-banner.png" class="card-img-top" alt="Planting Saplings" width="100%" height="220px">
                <div class="card-body text-center">
                    <p class="card-text">Volunteers Planting Saplings</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-lg">
                <img src="https://res.cloudinary.com/jerrick/image/upload/d_642250b563292b35f27461a7.png,f_jpg,fl_progressive,q_auto,w_1024/6635f1535addae001d447a0d.png" class="card-img-top" alt="Green Initiative">
                <div class="card-body text-center">
                    <p class="card-text">Making Earth Greener Together</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Latest Events Preview -->
<section class="container my-5" id="event">
    <h2 class="text-success fw-bold">Upcoming Events</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card"></div>
            <img src="https://media.assettype.com/sentinelassam-english%2F2025-06-06%2Fm7b9nh57%2FWorld-Environment-Day.webp?w=480&dpr=2&auto=format%2Ccompress&fit=max&q=85"class="card-img-top" alt="Plantation Drive at Pune">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Plantation Drive at Pune</h5>
                    <p class="card-text">Join us to plant 500 trees in local parks.</p>
                    <a href="events.php" class="btn btn-success btn-sm">View Events</a>
                    <a href="volunteer.php" class="btn btn-success btn-sm">Register</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://trilliontrees.org/wp-content/uploads/2022/07/money-2724241_1920_Pixabay_Nattanan-Kanchanaprat.jpg"class="card-img-top" alt="Forest Restoration Drive">
                <div class="card-body">
                    <h5 class="card-title">Forest Restoration Drive</h5>
                    <p class="card-text">Participate in restoring degraded forest areas.</p>
                    <a href="events.php" class="btn btn-success btn-sm">View Events</a>
                    <a href="volunteer.php" class="btn btn-success btn-sm">Register</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="container my-5" id="events">
<h2 class="text-success fw-bold"></h2>
<h2 class="text-success fw-bold">Past Events</h2>
<div class="row my-4">
<div class="col-md-4">
<div class="card mb-3">
    <img src="https://i.ytimg.com/vi/eStvuW9lFtw/maxresdefault.jpg" class="card-img-top" alt="Plantation Drive Sinhgad">
<div class="card-body">
<h5 class="card-title">Plantation Drive - Sinhgad</h5>
<p class="card-text">Join us to plant 500 trees at local parks. Date: 5th Dec 2025</p>
<!-- <a href="volunteer.php" class="btn btn-success btn-sm">Register</a> -->

</div>
</div>
</div>

<div class="col-md-4">
<div class="card mb-3">
    <img src="https://themachinemaker.com/wp-content/uploads/2025/08/Tata-Power-Tree-Plantation-Drive.jpeg" class="card-img-top" alt="Tree Plantation - Lonavala">
<div class="card-body">
<h5 class="card-title">Tree Plantation- Lonavala</h5>
<p class="card-text">Help restore degraded forest areas. Date: 15th Dec 2025</p>
<!-- <a href="volunteer.php" class="btn btn-success btn-sm">Register</a> -->
</div>
</div>
</div>

<div class="col-md-4">
<div class="card mb-3">
    <img src="https://www.dsndp.com/images/activities/plantation/treeConservation/Vasai_Virar/tree_plantation_vasai_virar_1.jpg" class="card-img-top" alt="Plantation Drive Sinhgad">
<div class="card-body">
<h5 class="card-title">Awareness Campaign - Pune</h5>
<p class="card-text">Spread awareness about deforestation. Date: 20th Dec 2025</p>
<!-- <a href="volunteer.php" class="btn btn-success btn-sm">Register</a> -->
</div>
</div>
</div>
</div>
</section>

<section class="container my-5 contact-section" id="contact">
    <!-- Section Heading -->
    <h2 class="text-center text-white fw-bold mb-3">Contact Us</h2>
    <p class="text-center text-light">Have questions or suggestions? Reach out to us! 🌟</p>

    <!-- Contact Form -->
    <form class="contact-form mx-auto" style="max-width: 600px;">
        <div class="mb-3">
            <label class="form-label text-white">Name</label>
            <input type="text" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label text-white">Email</label>
            <input type="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label text-white">Message</label>
            <textarea id="message" class="form-control" rows="5" required></textarea>
        </div>

        <!-- Emoji Picker -->
        <div class="emoji-picker mb-3">
            <span class="emoji" onclick="addEmoji('😊')">😊</span>
            <span class="emoji" onclick="addEmoji('🌱')">🌱</span>
            <span class="emoji" onclick="addEmoji('💚')">💚</span>
            <span class="emoji" onclick="addEmoji('🌳')">🌳</span>
            <span class="emoji" onclick="addEmoji('✨')">✨</span>
        </div>

        <button type="submit" class="btn btn-light btn-lg w-100">Send Message</button>
    </form>
</section>

<!-- Emoji Script -->
<script>
function addEmoji(emoji) {
    const messageBox = document.getElementById('message');
    messageBox.value += emoji; // append emoji to the message
    messageBox.focus();
}
</script>

</section>
<!-- Footer -->
<footer class="bg-success text-white text-center p-3 mt-5">
    <p class="mb-0">© 2025 Green Rangers | Pune, India</p>
    <p class="mb-0">Contact: greenrangers@gmail.com</p>
</footer>
<script>
    const sections = document.querySelectorAll("section");

    const revealSection = () => {
        sections.forEach(section => {
            const sectionTop = section.getBoundingClientRect().top;
            if (sectionTop < window.innerHeight - 100) {
                section.style.opacity = "1";
                section.style.transform = "translateY(0)";
            }
        });
    };

    sections.forEach(section => {
        section.style.opacity = "0";
        section.style.transform = "translateY(40px)";
        section.style.transition = "all 0.8s ease";
    });

    window.addEventListener("scroll", revealSection);
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="script.js"></script>
</body>
</html>
