<?php
include 'config.php';

if (isset($_POST['submit'])) {

    $name      = $_POST['name'];
    $email     = $_POST['email'];
    $phone     = $_POST['phone'];
    $type      = $_POST['type']; // admin
    $password  = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    // password match check
    if ($password !== $cpassword) {
        echo "<script>alert('Passwords do not match'); window.history.back();</script>";
        exit;
    }

    // check existing email
    $check = "SELECT adminid FROM admindetails WHERE email='$email'";
    $result = mysqli_query($db, $check);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Email already registered'); window.history.back();</script>";
        exit;
    }

    // MD5 encryption
    $md5Password = md5($password);

    // insert data
    $query = "INSERT INTO admindetails (name, email, phone, password, type)
              VALUES ('$name', '$email', '$phone', '$md5Password', '$type')";

    if (mysqli_query($db, $query)) {
        echo "<script>alert('Registration Successful'); window.location='../admin/admin.php';</script>";
    } else {
        echo "<script>alert('Something went wrong'); window.history.back();</script>";
    }
}
?>
