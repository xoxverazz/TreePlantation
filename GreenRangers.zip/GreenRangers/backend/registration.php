<?php


include 'config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;



if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $cpassword = md5($_POST['cpassword']);
    // $phone = $_POST['phone'];
    $event = $_POST['event'];

    $select = " SELECT * FROM users WHERE email = '$email' && password = '$password' ";

    $result = mysqli_query($db, $select);

    if (mysqli_num_rows($result) > 0) {

       echo "<script>alert('User already exists!'); window.location.href='../frontend/volunteer.php';</script>";
       exit();


    } else {

        if ($password != $cpassword) {
     echo "<script>alert('Password not matched!'); window.location.href='../frontend/volunteer.php';</script>";
     exit();

        } else {
            $insert = "INSERT INTO users(name, email, password, phone, event) VALUES('$name', '$email', '$password', '$phone', '$event')";
            echo $insert;
            mysqli_query($db, $insert);


//Load Composer's autoloader (created by composer, not included with PHPMailer)
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/PHPMailer.php';
//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'deshmukhgaurav184@gmail.com';                     //SMTP username
    $mail->Password   = 'rmaopjmeblzqjmkm';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('deshmukhgaurav184@gmail.com', 'Green Rangers');
    $mail->addAddress($email ,$name );     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Registration Successful - Green Rangers';
    $mail->Body    = '<body style="font-family: Arial, sans-serif; background-color: #f4f8f4; padding: 20px;">

    <div style="max-width: 600px; margin: auto; background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
        
        <h2 style="color: #2e7d32;">Dear Participant,</h2>

        <p>
            Thank you for registering for the <strong>Tree Plantation Drive </strong>
        </p>

        <p>
            We are happy to inform you that your registration has been 
            <strong>successfully completed</strong>. Your participation is a valuable step towards creating a greener and healthier environment.
        </p>

        <h3 style="color: #388e3c;">What’s next?</h3>

        <ul>
            <li>Event details (date, time, and location) will be shared with you soon.</li>
            <li>Please keep this email for future reference.</li>
        </ul>

        <p>
            Together, let us contribute to nature and make a positive impact on our planet.
        </p>

        <p>
            If you have any questions, feel free to contact us.
        </p>

        <p style="margin-top: 30px;">
            Warm regards,<br>
            <strong>Lilly Daniel</strong><br>
            <strong>Gaurav Deshmukh</strong><br>
            <strong>Green Rangers Team</strong>
        </p>

    </div>

</body>';
   

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
            header('location: ../frontend/login.php ');
        }
    }

};

?>