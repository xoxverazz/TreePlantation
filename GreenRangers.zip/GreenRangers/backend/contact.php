<?php
include "../backend/config.php";   // adjust path if needed

if (isset($_POST['submit'])) {

    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $message = $_POST['message'];

    $query = "INSERT INTO contact_messages (name, email, message)
              VALUES ('$name', '$email', '$message')";

    if ($db->query($query)) {
        echo "<script>
                alert('Message sent successfully!');
                window.location.href='../frontend/index.php';
              </script>";
    } else {
        echo "<script>
                alert('Something went wrong. Try again!');
                window.history.back();
              </script>";
    }
}
?>
