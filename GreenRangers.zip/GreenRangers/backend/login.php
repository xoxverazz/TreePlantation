<?php
include 'config.php';
session_start();

if (isset($_POST['submit'])) {

    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $select = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($db, $select);

    if (mysqli_num_rows($result) > 0) {

        $row = mysqli_fetch_array($result);

        // Store user info in session
        $_SESSION['user_name'] = $row['name'];
        $_SESSION['user_email'] = $row['email'];
        $_SESSION['user_phone'] = $row['phone'];
        $_SESSION['event'] = $row['event'];


        header('location: ../frontend/dashboard.php');  
        exit();

    } else {
        echo "
        <script>
        alert('Incorrect Email or Password!');
        window.location.href='../frontend/login.php';
        </script>";
    }
}
?>
