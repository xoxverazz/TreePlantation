<?php
session_start();
include 'config.php';

if (isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = md5($_POST['password']); // MD5 here

    $query = "SELECT * FROM admindetails WHERE email='$email' AND password='$password'";
    $result = mysqli_query($db, $query);

    if (mysqli_num_rows($result) == 1) {

        $user = mysqli_fetch_assoc($result);

        $_SESSION['user_id'] = $user['adminid'];
        $_SESSION['name']    = $user['name'];
        $_SESSION['type']    = $user['type'];

        echo $user['adminid'], $user['name'], $user['type'];
        if ($user['type'] == 'admin') {
            header("Location: ../admin/admin.php");
        } else {
            header("Location: ../frontend/index.php");
        }
        exit;

    } else {
        echo "<script>alert('Invalid Email or Password'); window.history.back();</script>";
    }
}
?>
