<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "green_rangers";

$db = mysqli_connect($servername, $username, $password, $dbname);

if ($db) {
       // echo "Connection success" ;
        
} else {
     echo "Connection faild";
}
?>